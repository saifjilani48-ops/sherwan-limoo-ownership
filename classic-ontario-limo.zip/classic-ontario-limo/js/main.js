// Classic Ontario Limo - site scripts

var EMAIL = 'classicontariolimo@gmail.com';
var IMG_BASE = 'https://media.base44.com/images/public/6a00fb8d57def44ca97fd380/';

var fleet = [
  { name: 'Lexus ES 350 Luxury Sedan', tag: 'Executive sedan', pax: 3, bags: 3, img: 'images/car.jpeg',
    text: 'Refined Japanese craftsmanship, plush leather seating, and whisper-quiet executive comfort for airport transfers and VIP city travel.' },
  { name: 'Cadillac Escalade ESV Platinum', tag: 'Executive choice', pax: 6, bags: 5, img: IMG_BASE + 'f090f455b_generated_image.png',
    text: 'Effortless power and whisper-quiet refinement for executives who expect the best.' },
  { name: 'GMC Yukon XL Denali Ultimate', tag: 'Premium class', pax: 6, bags: 5, img: IMG_BASE + '6da890299_generated_image.png',
    text: 'Bold design and sophisticated engineering for a first-class ride across the GTA.' },
  { name: 'Lincoln Navigator Black Label L', tag: 'Luxury choice', pax: 7, bags: 5, img: IMG_BASE + '42ad83497_generated_image.png',
    text: 'Serene, spacious and supremely appointed.' },
  { name: 'Mercedes-Benz S-Class S500', tag: 'Executive sedan', pax: 3, bags: 3, img: IMG_BASE + '8c0ecc784_generated_image.png',
    text: 'The luxury sedan for discerning executives.' },
  { name: 'Luxury Party Bus Executive Coach', tag: 'Party bus', pax: 30, bags: 2, img: IMG_BASE + 'cd29f8a9a_generated_image.png',
    text: 'A mobile venue for celebrations, corporate events and VIP groups.' },
  { name: 'Mercedes-Benz Sprinter Limo Van', tag: 'Luxury Van', pax: 14, bags: 10, img: 'images/sprinter-limo.jpg',
    text: 'Luxury Mercedes-Benz Sprinter Limo van chauffeur service for Pearson transfers, executive travel and group transportation.' }
];

/* ---------- fleet cards ---------- */
var track = document.getElementById('fleetTrack');
fleet.forEach(function (v) {
  var card = document.createElement('article');
  card.className = 'card fleet-card';
  card.innerHTML =
    '<div class="fleet-img">' +
      '<img src="' + v.img + '" alt="' + v.name + '" loading="lazy">' +
      '<span class="pill">' + v.tag + '</span>' +
      '<span class="cap">' + v.pax + ' seats &middot; ' + v.bags + ' bags</span>' +
    '</div>' +
    '<div class="fleet-body">' +
      '<h3>' + v.name + '</h3>' +
      '<p>' + v.text + '</p>' +
      '<a href="#quote" class="btn btn-gold" data-vehicle="' + v.name + '">Reserve This Vehicle &#8599;</a>' +
    '</div>';
  track.appendChild(card);
});

/* ---------- quote form ---------- */
var form = document.getElementById('quoteForm');
var panels = form.querySelectorAll('.step-panel');
var tabs = form.querySelectorAll('.step-tab');
var backBtn = document.getElementById('backBtn');
var nextBtn = document.getElementById('nextBtn');
var doneBtn = document.getElementById('doneBtn');
var paxSelect = document.getElementById('pax');
var vehicleSelect = document.getElementById('vehicle');
var serviceType = 'Airport transfer';
var step = 0;

[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 15, 20, 30].forEach(function (n) {
  paxSelect.add(new Option(n + (n > 1 ? ' passengers' : ' passenger'), n));
});

function fillVehicles() {
  var pax = Number(paxSelect.value);
  var current = vehicleSelect.value;
  vehicleSelect.innerHTML = '';
  fleet.filter(function (v) { return v.pax >= pax; }).forEach(function (v) {
    vehicleSelect.add(new Option(v.name, v.name));
  });
  vehicleSelect.add(new Option('Recommend a vehicle', 'Recommend a vehicle'));
  // keep the old choice if it still fits
  var stillThere = Array.prototype.some.call(vehicleSelect.options, function (o) { return o.value === current; });
  vehicleSelect.value = stillThere ? current : 'Recommend a vehicle';
  showPreview();
}

function showPreview() {
  var v = fleet.filter(function (x) { return x.name === vehicleSelect.value; })[0];
  var img = document.getElementById('previewImg');
  img.hidden = !v;
  if (v) { img.src = v.img; img.alt = v.name; }
  document.getElementById('previewName').textContent = v ? v.name : 'Let us recommend the right vehicle';
  document.getElementById('previewText').textContent = v ? v.text : 'Share your group size and we will match the premier luxury vehicle.';
  document.getElementById('previewSeats').textContent = v ? v.pax + ' seats \u00b7 ' + v.bags + ' bags' : '';
}

function showStep(n) {
  step = n;
  panels.forEach(function (p, i) { p.hidden = i !== n; });
  tabs.forEach(function (t, i) { t.classList.toggle('active', i <= n); });
  backBtn.hidden = n === 0;
  nextBtn.hidden = n === panels.length - 1;
  doneBtn.hidden = n !== panels.length - 1;
}

// check only the fields in the current step
function stepIsValid() {
  var ok = true;
  panels[step].querySelectorAll('input[required]').forEach(function (inp) {
    inp.classList.add('touched');
    if (!inp.checkValidity()) {
      if (ok) inp.reportValidity();
      ok = false;
    }
  });
  return ok;
}

document.querySelectorAll('.type-btn').forEach(function (btn) {
  btn.addEventListener('click', function () {
    document.querySelector('.type-btn.active').classList.remove('active');
    btn.classList.add('active');
    serviceType = btn.textContent;
  });
});

paxSelect.addEventListener('change', fillVehicles);
vehicleSelect.addEventListener('change', showPreview);
backBtn.addEventListener('click', function () { showStep(step - 1); });
nextBtn.addEventListener('click', function () { if (stepIsValid()) showStep(step + 1); });

form.addEventListener('submit', function (e) {
  e.preventDefault();
  if (!stepIsValid()) return;
  var val = function (id) { return document.getElementById(id).value; };
  var msg = 'Classicontariolimo Booking Request (' + serviceType + ')\n' +
    'Name: ' + val('name') + '\n' +
    'Phone: ' + val('phone') + '\n' +
    'From: ' + val('from') + '\n' +
    'To: ' + val('to') + '\n' +
    'Date & Time: ' + val('date') + ' at ' + val('time') + '\n' +
    'Passengers: ' + val('pax') + '\n' +
    'Vehicle: ' + val('vehicle') + '\n' +
    'Please provide fixed quote confirmation.';
  window.location.href = 'mailto:' + EMAIL +
    '?subject=' + encodeURIComponent('Priority Fixed Rate Inquiry from ' + val('name')) +
    '&body=' + encodeURIComponent(msg);
});

// "Reserve This Vehicle" buttons pre-select that car in the form
track.addEventListener('click', function (e) {
  var link = e.target.closest('[data-vehicle]');
  if (!link) return;
  var name = link.getAttribute('data-vehicle');
  var v = fleet.filter(function (x) { return x.name === name; })[0];
  if (Number(paxSelect.value) > v.pax) paxSelect.value = 1;
  fillVehicles();
  vehicleSelect.value = name;
  showPreview();
});

fillVehicles();
showStep(0);

/* ---------- contact form ---------- */
document.getElementById('contactForm').addEventListener('submit', function (e) {
  e.preventDefault();
  var name = document.getElementById('cName').value;
  var body = 'Inquiry for Classicontariolimo:\n' +
    'Name: ' + name + '\n' +
    'Phone: ' + document.getElementById('cPhone').value + '\n' +
    'Email: ' + document.getElementById('cEmail').value + '\n\n' +
    'Message:\n' + document.getElementById('cMsg').value;
  window.location.href = 'mailto:' + EMAIL +
    '?subject=' + encodeURIComponent('Priority Reservation Inquiry from ' + name) +
    '&body=' + encodeURIComponent(body);
});
